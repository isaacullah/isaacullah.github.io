extensions [csv]
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; AGENTS AND VARIABLES ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

breed [ interests interest]
breed [ pmakers pmaker]
breed [ coalitions coalition ]
breed [ indicators indicator ]


globals [
  fishpop                ; fish population available for harvesting
  rrate                  ; reproduction rate for fish
  ccapacity              ; carrying capacity of the 'environment'
  catch                  ; catch by industry during current season
  price                  ; price of fish
  income                 ; income received by industry during current season after selling catch
  capital                ; aggregated profits over time
  quota                  ; amount of fish allowed to be harvested per season
  salience               ; salience of fishery issue, determines importance of salience
  lcost                  ; cost of lobbying activity
  vote-increase          ; used to tally total votes
  vote-decrease          ; used to tally total votes
  lobby-increase         ; number of interest groups lobbying for quota increase (including groups in coalitions)
  lobby-decrease         ; number of interest groups lobbying for quota decrease (including groups in coalitions)
  %marginal_industry     ; number of industry IGs with extreme values
  %central_industry      ; number of industry IGs with moderate values
  %marginal_env          ; number of environment IGs with extreme values
  %central_env           ; number of environment IGs with moderate values
  plot-influence-ind     ; used to plot total influence of industry lobby
  plot-influence-env     ; used to plot total influence of environment lobby
  plot-funding-ind       ; used to plot total funding of industry lobby
  plot-funding-env       ; used to plot total funding of environment lobby
  mean-n-members         ; used to find average # of members in coalitions
  n-coalitions-e         ; number of environmental coalitions in the system
  n-coalitions-i         ; number of industry coalitions in the system
  n-poor-e               ; number of members with insufficient funding for environmental coalitions
  n-poor-i               ; number of members with insufficient funding for industry coalitions
  infl-in-coalitions-i   ; % of total industry influence taken up by industry coalitions
  infl-in-coalitions-e   ; % of total industry influence taken up by environmental coalitions
  list-e-members         ; list, containing number of members in each Environmental IG coalition
  list-i-members         ; list, containing number of members in each Industry IG coalition
  mean-e-members
  mean-i-members
  target
  lobby-e-infl
  lobby-i-infl
]

interests-own [
  itype                  ; type of interest group - industry or environmental
  values                 ; pro-environmental vs industry values, where 1 - extreme pro-industry, 10 - extreme pro-environmental
  bias                   ; extent to which group exaggerates received signal
  concern-t              ; threshold for signal at which interest group perceives issue as 'critical' and decides to lobby
  concern                ; used to indicate whether IG is 'concerned' this season
  policygoal             ; policy goal that interest group decides to lobby for (increase or decrease of quota)
  influence              ; influence assigned to IGs at start of season (not including influence derived from public opinion)
  current-influence      ; influence of IG at the start of lobbying procedure
  funding                ; set amount of funding assigned to IG at the start of season
  lfunds                 ; funding availble to IGs at the start of lobbying procedure
  lobbying               ; indicates whether interest groups will participate in lobbying this season
  allying                ; indicates whether interest group is planning to build/seek coalition
  availability           ; indicates if interest group is available for coalition-building
  coalition-id           ; indicates ID of coalition the interest group belongs to
  needfunds              ; indicates whether interest group has enough funds to lobby at least once this season
  biding-time            ; set to true if the interest group has to skip the first round of coalition-building and try allying in the second round after new coalitions have been formed
  potential-allies       ; set of interest groups that are close enough in values to ally with
  in-coalition           ; indicates whether an interest group is a member of a coalition
  v-type                 ; interest group position on the value scale ( marginal/central/moderate )


]

pmakers-own [
  values                ; pro-environmental vs industry values, where 1 - extreme pro-industry, 10 - extreme pro-environmental
  favor                 ; policymaker's favor for the policy options
]

coalitions-own [
  values                ; pro-environmental vs industry values, where 1 - extreme pro-industry, 10 - extreme pro-environmental
  policygoal            ; policy goal that coalition decides to lobby for (increase or decrease of quota)
  current-influence     ; influence of coalition at the start of lobbying procedure
  lfunds                ; funding availble to coalition at the start of lobbying procedure
  id                    ; id of coalition (shared with its members)
  members               ; set of interest groups who are members of the coalition
  availability          ; indicates if coalition is available for more members (always true)
  lobbying              ; indicates whether the coalition is lobbying (always true)
  potential-allies      ; set of interest groups that are close enough in values to ally with
  num-environment       ; number of environmental IGs who are members of the coalition
  num-industry          ; number of industry IGs who are members of the coalition
  %-environment         ; % of environment IG members
  %-industry            ; % of industry IG members
  mean-values           ; mean values of members
  median-values         ; median values of members
  mean-funding          ; mean funding of members
  median-funding        ; median funding of members
  mean-influence        ; mean influence of members
  median-influence      ; median influence of members
  n-members             ; total # members
  n-poor                ; number of groups with insufficient funding for lobbying
  history-influence     ; list which indicates how influence of coalition changed with addition of new members

]


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; SETUP PROCEDURES ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

to setup
  clear-all
  init-vars
  if experiment != "no IGs" [ make-interests ]
  make-pmakers
  add-visuals
  reset-ticks
  tick
end

to init-vars
  set fishpop fish-population
  set rrate reproduction-rate
  set ccapacity carrying-capacity
  set price 1                            ;;; PRICE OF FISH - introduce a slider if need to look at market effects
  set quota starting-quota
  set income starting-quota
  set salience pro-environmental%
  set lcost lobbying-cost
  set vote-increase 0
  set vote-decrease 0
  set lobby-increase 0
  set lobby-decrease 0

end

;;;;;;;;;;;;;; PROCEDURE FOR BOUNDED NORMAL DISTRIBUTION ;;;;;;;;;;;;;;

to-report random-normal-in-bounds [ mid dev mmin mmax ]
  let result random-normal mid dev
  if result < mmin or result > mmax
    [ report random-normal-in-bounds mid dev mmin mmax ]
  report result
end

;;;;;;;;;;;;;; Makes interest groups of 2 types, distributes values/funding/influence ;;;;;;;;;;;;;;;;;;;
to make-interests
  create-interests 100 [
    setxy random-xcor random-ycor
    set itype "industry"
    set color yellow
    set shape "factory"
    set size 2
    set availability true
    set coalition-id who
    set needfunds false
    set biding-time false
    set values 0
    set influence 0
    set funding 0
    set v-type 0
  ]
  create-interests 100 [
    setxy random-xcor random-ycor
    set itype "environment"
    set color blue
    set shape "fish"
    set size 2
    set availability true
    set coalition-id who
    set needfunds false
    set biding-time false
    set values 0
    set influence 0
    set funding 0
    set v-type 0
  ]

  if IG-values = "Marginals only" [
    set %marginal_industry 100
    set %central_industry 0
    set %marginal_env 100
    set %central_env 0
  ]

  if IG-values = "Centrals only" [
    set %marginal_industry 0
    set %central_industry 100
    set %marginal_env 0
    set %central_env 100
  ]

  if IG-values = "Extremes only" [
    set %marginal_industry 50
    set %central_industry 50
    set %marginal_env 50
    set %central_env 50
  ]

  if IG-values = "Moderates only" [
    set %marginal_industry 0
    set %central_industry 0
    set %marginal_env 0
    set %central_env 0
  ]

  if IG-values = "Normal distribution" [
    set %marginal_industry 10
    set %central_industry 10
    set %marginal_env 10
    set %central_env 10
  ]

ask n-of %marginal_industry interests with [ itype = "industry" and v-type = 0 ] [set v-type "marginal"]
ask n-of %central_industry interests with [ itype = "industry" and v-type = 0 ] [set v-type "central"]
if any? interests with [ itype = "industry" and v-type = 0 ] [ ask interests with [ itype = "industry" and v-type = 0 ] [set v-type "moderate" ] ]
ask n-of %marginal_env interests with [ itype = "environment" and v-type = 0 ] [set v-type "marginal"]
ask n-of %central_env interests with [ itype = "environment" and v-type = 0 ] [set v-type "central"]
if any? interests with [ itype = "environment" and v-type = 0 ] [ ask interests with [ itype = "environment" and v-type = 0 ] [set v-type "moderate" ] ]

ask interests with [itype = "industry"] [
  set funding random-normal-in-bounds mean-funding-industry (mean-funding-industry / 2) 0 (mean-funding-industry * 2)
  set influence random-normal-in-bounds mean-influence-industry (mean-influence-industry / 2) 0 (mean-influence-industry * 2) ]

ask interests with [itype = "environment"] [
  set funding random-normal-in-bounds mean-funding-environment (mean-funding-environment / 2) 0 (mean-funding-environment * 2)
  set influence random-normal-in-bounds mean-influence-environment (mean-influence-environment / 2) 0 (mean-influence-environment * 2) ]

  ;;ask interests with [ itype = "industry" and v-type = "marginal"] [
    ;;set values 1 + random 1
    ;;set funding random-normal mean-funding-industry 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-industry 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]
  ;;ask interests with [ itype = "industry" and v-type = "moderate"] [
    ;;set values 3
    ;;set funding random-normal mean-funding-industry 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-industry 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]
  ;;ask interests with [ itype = "industry" and v-type = "central"]  [
    ;;set values 4 + random 1
    ;;set funding random-normal mean-funding-industry 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-industry 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]
  ;;ask interests with [ itype = "environment" and v-type = "marginal"] [
    ;;set values 9 + random 1
    ;;set funding random-normal mean-funding-environment 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-environment 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]
  ;;ask interests with [ itype = "environment" and v-type = "moderate"] [
    ;;set values 8
    ;;set funding random-normal mean-funding-environment 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-environment 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]
  ;;ask interests with [ itype = "environment" and v-type = "central"]  [
    ;;set values 6 + random 1
    ;;set funding random-normal mean-funding-environment 1
    ;;if funding < 0 [ set funding 0 ]
    ;;set influence random-normal mean-influence-environment 1
    ;;if influence < 0 [ set influence 0 ]
  ;;]

ask interests with [ itype = "industry" ] [
  set bias bias-industry
  set concern-t concern-threshold-industry
  set lfunds funding
]

ask interests with [ itype = "environment" ] [
  set bias bias-environment
  set concern-t concern-threshold-environment
  set lfunds funding
]

  ;;report-influence

end

;;;;;;;;;;;; Creates policymakers, distributes values ;;;;;;;;;;;;;;;;;;;
to make-pmakers
  if PM-values = "20-60-20" [
    create-pmakers 20 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 1 + random-float 2
    ]
  create-pmakers 30 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 5
  ]
  create-pmakers 30 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 6
  ]
  create-pmakers 20 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8 + random-float 2
  ]
  ]

  if PM-values = "51-49" [
    create-pmakers 51 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 3
    ]
  create-pmakers 49 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8
  ]
  ]

    if PM-values = "49-51" [
    create-pmakers 49 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 3
    ]
  create-pmakers 51 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8
  ]
  ]

  if PM-values = "40-20-40" [
    create-pmakers 40 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 1 + random-float 2
    ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 5
  ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 6
  ]
  create-pmakers 40 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8 + random-float 2
  ]
  ]
  if PM-values = "39-20-41" [
    create-pmakers 39 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 1 + random-float 2
    ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 5
  ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 6
  ]
  create-pmakers 41 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8 + random-float 2
  ]
  ]

   if PM-values = "41-20-39" [
    create-pmakers 41 [
      setxy random-xcor random-ycor
      set color white
      set shape "person business"
      set size 2
      set values 1 + random-float 2
    ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 5
  ]
  create-pmakers 10 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 6
  ]
  create-pmakers 39 [
    setxy random-xcor random-ycor
    set color white
    set shape "person business"
    set size 2
    set values 8 + random-float 2
  ]
  ]
  ask pmakers [ set favor values ]
end



to add-visuals
  create-indicators 1 [
    setxy 15 15
    set size 2
    set color white
    set shape "x"
  ]
end

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;; GO PROCEDURES ;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

to go
  clear-the-board
  if experiment != "no IGs" [
    perceive-signals
    set-goals-and-influence
    decide-coalitions
    build-coalitions
    lobby
    ;;report-history
  ]
  vote-and-decide
  update-resource
  harvest-and-sell
  shifting-salience
  tick
end

;; Procedure of resource reproduction/renewal
;; Logistic growth with carrying capacity (can be set via slider)
to update-resource
  set fishpop fishpop + (rrate * fishpop * ( 1 - (fishpop / ccapacity)))
end

;; Procedure that determines the seasonal harvest of the resource (not more than set quota) and income that resource user receives this season
;; TO DO: think of compliance

to harvest-and-sell
  ifelse quota > 0 [
    ifelse fishpop > quota [
      set catch quota
    ]
    [ set catch fishpop ]
    set fishpop fishpop - catch
    set income (catch * price)
    set capital capital + income
  ]
  [ set catch 0
    set income 0
  ]
end

to shifting-salience
  ifelse dynamic-salience = true [
    ifelse fishpop >= 0.5 * ccapacity
    [ set salience 0
    ]
    [ set salience 1 - (fishpop / ( pub-threshold))
      if salience <= 0 [set salience 0]
    ]
  ]
  [ set salience 0]
end

;;;;;;;;;;; Gives interest groups the information about state of resource and incomes (for this season!) ;;;;;;;;;;;;
to perceive-signals
  ask interests [
    if itype = "industry" [
      let profit-signal income - bias
      ifelse profit-signal < concern-threshold-industry
      [ set concern true ]
      [ set concern false ]
    ]
    if itype = "environment" [
      let environment-signal fishpop - bias
      ifelse environment-signal < concern-threshold-environment
      [ set concern true  ]
      [ set concern false ]
    ]
  ]
end

;;;;;;;;;;;;;; Calculates & sets influence for the environmental IGs (based on issue salience + actual influence) and influence for industry IGs
;;;;;;;;;;;;;; Sets policy goals, based on group type
to set-goals-and-influence
  ask interests [
    if itype = "environment" [
      set current-influence (influence + (salience * (mean-influence-environment * 2) * issue-salience) )
      set policygoal "decrease quota"
    ]
    if itype = "industry"    [
      set current-influence influence
      set policygoal "increase quota"
    ]
  ]
end

;;;;;;;;;;;;;; Procedure for IGs to decide whether to ally or not. IGs decide to ally if concerned or lacking funds ;;;;;;;;;;;;
to decide-coalitions
  ask interests [
    ifelse lfunds > lcost
    [ set needfunds false ]
    [ set needfunds true ]

    if experiment = "none" or experiment = "IGs & coalitions"  [

      ifelse concern = true
      [ ifelse likelihood-coalition >= random-float 1
        [set allying true
          set availability true]
        [set allying false
          set availability false]
      ]
      [set allying false
        set availability false ]
    ]
  ]
end

;;;;;;;;;;;;; Procedure for coalition-building ;;;;;;;;;;;;;;;;
to build-coalitions
  ifelse experiment = "none" or experiment = "IGs & coalitions"
  [
    ask interests [
      if allying = true [
        let mypref values
        let other-interests other turtles with [ breed = interests ]
        set potential-allies other-interests with [ ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        if single-type-coalitions = true [
          set potential-allies other-interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        ]
        ifelse any? potential-allies
        [ set availability true ]
        [ set availability false
          set biding-time true
        ]
      ]
    ]
;;;;;;; I round ;;;;;;;;
    ask interests [
      if allying = true and biding-time = false  [
        ;;print "I will ally"
        let mypref values
        let other-interests other turtles with [ breed = interests or breed = coalitions ]
        if coalition-formation = "capped" [ set other-interests other turtles with [ (breed = interests) or (breed = coalitions and n-members < 10) ] ]
        set potential-allies turtle-set other-interests with [ ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        if single-type-coalitions = true [
          set potential-allies other-interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        ]
        let groups-with-resources potential-allies with [ lfunds >= lcost - [ lfunds ] of self and availability = true ]
        ;;if any? groups-with-resources [print "I see friends"]
        ifelse groups-with-resources = nobody
        [ set availability false
          set biding-time true
        ]
        [ while [ any? groups-with-resources and allying = true ] [
          if coalition-choice = "high influence" [ set target max-one-of groups-with-resources [ current-influence ] ]
          if coalition-choice = "high funding" [ set target max-one-of groups-with-resources [ lfunds ] ]
          if coalition-choice = "random" [ set target one-of groups-with-resources ]
          let initiator self
          if [ breed ] of target = interests [
            ifelse coalition-formation = "probability" [
              ifelse (member? initiator [ potential-allies ] of target) and (likelihood-coalition >= random-float 1)
              [ ;;print "I am allying"
                set lobbying false
                set allying false
                set availability false
                set in-coalition true
                ask target [ set lobbying false
                  set allying false
                  set availability false
                  set in-coalition true
                  set coalition-id [ coalition-id ] of initiator
                ]
                hatch-coalitions 1 [
                  setxy random-xcor random-ycor
                  set shape "circle"
                  set size 2
                  set id [ coalition-id ] of initiator
                  set availability true
                  set history-influence []
                  set members interests with [ coalition-id = [ id ] of myself ]
                  set n-members count members
                  let list-our-values [ values ] of members
                  set values mean list-our-values
                  set current-influence sum [current-influence] of members
                  set lfunds sum [ lfunds ] of members
                  let ourpref values
                  set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                  if single-type-coalitions = true [
                    set potential-allies other-interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                  ]
                  set lobbying true
                  set policygoal [ policygoal ] of max-one-of members [current-influence]
                  set history-influence fput  current-influence history-influence
                  ;;create-links-with members
                ]
              ]
              [ set groups-with-resources groups-with-resources with [ who != [ who ] of target ] ]
            ]
            [ ifelse member? initiator [ potential-allies ] of target
              [ ;;print "I am allying"
                set lobbying false
                set allying false
                set availability false
                set in-coalition true
                ask target [ set lobbying false
                  set allying false
                  set availability false
                  set in-coalition true
                  set coalition-id [ coalition-id ] of initiator
                ]
                hatch-coalitions 1 [
                  setxy random-xcor random-ycor
                  set shape "circle"
                  set size 2
                  set id [ coalition-id ] of initiator
                  set availability true
                  set history-influence []
                  set members interests with [ coalition-id = [ id ] of myself ]
                  set n-members count members
                  let list-our-values [ values ] of members
                  set values mean list-our-values
                  set current-influence sum [current-influence] of members
                  set lfunds sum [ lfunds ] of members
                  let ourpref values
                  set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                  if single-type-coalitions = true [
                    set potential-allies other-interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                  ]
                  set lobbying true
                  set policygoal [ policygoal ] of max-one-of members [current-influence]
                  ;;create-links-with members
                ]
              ]
              [ set groups-with-resources groups-with-resources with [ who != [ who ] of target ] ]
            ]
          ]
          if [ breed ] of target = coalitions [
            ifelse coalition-formation = "probability" [
              ifelse (member? initiator [ potential-allies ] of target) and (likelihood-coalition >= random-float 1)
              [ set lobbying false
                set allying false
                set availability false
                set in-coalition true
                set coalition-id [ id ] of target
                if coalition-influence = "diminishing returns" [ set current-influence current-influence * (1 - (count [ members ] of target) / 100) ]
                ask target [
                  set members interests with [ coalition-id = [ id ] of myself ]
                  set n-members count members
                  let list-our-values [ values ] of members
                  set values mean list-our-values
                  set current-influence sum [current-influence] of members
                  set history-influence fput current-influence history-influence
                  set lfunds sum [ lfunds ] of members
                  let ourpref values
                  set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                  if single-type-coalitions = true [
                    set potential-allies interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                  ]
                  set policygoal [ policygoal ] of max-one-of members [current-influence]
                  ;;create-link-with initiator
                ]
              ]
              [ set groups-with-resources groups-with-resources with [ who != [ who ] of target ] ]
            ]
            [ ifelse member? initiator [ potential-allies ] of target
              [ set lobbying false
                set allying false
                set availability false
                set in-coalition true
                set coalition-id [ id ] of target
                ask target [
                  set members interests with [ coalition-id = [ id ] of myself ]
                  set n-members count members
                  let list-our-values [ values ] of members
                  set values mean list-our-values
                  set current-influence sum [current-influence] of members
                  set history-influence fput current-influence history-influence
                  set lfunds sum [ lfunds ] of members
                  let ourpref values
                  set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                  if single-type-coalitions = true [
                    set potential-allies interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                  ]
                  set policygoal [ policygoal ] of max-one-of members [current-influence]
                  ;;create-link-with initiator
                ]
              ]
              [ set groups-with-resources groups-with-resources with [ who != [ who ] of target ] ]
            ]
          ]
        ]
        ]
        if groups-with-resources = nobody and allying = true [ set biding-time true ]
      ]
    ]
;;;;;;; II round ;;;;;;;;
    ask interests [
      if biding-time = true [
        let mypref values
        let coalition-friends turtle-set coalitions with [ ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        if single-type-coalitions = true [
          set coalition-friends turtle-set coalitions with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
        ]
        if coalition-formation = "capped" [ set coalition-friends coalition-friends with [ n-members < 10 ] ]
        let coalitions-with-resources coalition-friends with [ lfunds >= lcost - [ lfunds ] of myself ]
        while [ any? coalitions-with-resources = true ] [
          if coalition-choice = "high influence" [ set target max-one-of coalitions-with-resources [ current-influence ] ]
          if coalition-choice = "high funding" [ set target max-one-of coalitions-with-resources [ lfunds ] ]
          if coalition-choice = "random" [ set target one-of coalitions-with-resources ]
          let initiator self
          ifelse coalition-formation = "probability"
          [ ifelse (member? initiator [ potential-allies ] of target) and (likelihood-coalition >= random-float 1)
            [ set lobbying false
              set allying false
              set biding-time false
              set in-coalition true
              set coalition-id [ id ] of target
              if coalition-influence = "diminishing returns" [ set current-influence current-influence * (1 - (count [ members ] of target) / 100) ]
              ask target [
                set members interests with [ coalition-id = [ id ] of myself ]
                set n-members count members
                let list-our-values [ values ] of members
                set values mean list-our-values
                set current-influence sum [current-influence] of members
                set lfunds sum [ lfunds ] of members
                let ourpref values
                set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                if single-type-coalitions = true [
                  set potential-allies interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                ]
                set policygoal [ policygoal ] of max-one-of members [current-influence]
                set history-influence fput current-influence history-influence
                ;;create-link-with initiator
              ]
            ]
            [ set coalitions-with-resources coalitions-with-resources with [ who != [ who ] of target ] ]
          ]
          [ ifelse member? initiator [ potential-allies ] of target
            [ set lobbying false
              set allying false
              set biding-time false
              set in-coalition true
              set coalition-id [ id ] of target
              if coalition-influence = "diminishing returns" [ set current-influence current-influence * (1 - (count [ members ] of target) / 100) ]
              ask target [
                set members interests with [ coalition-id = [ id ] of myself ]
                set n-members count members
                let list-our-values [ values ] of members
                set values mean list-our-values
                set current-influence sum [current-influence] of members
                set lfunds sum [ lfunds ] of members
                let ourpref values
                set potential-allies interests with [ ( values > [ ourpref ] of myself - coalition-v-threshold ) and ( values < [ ourpref ] of myself + coalition-v-threshold ) ]
                if single-type-coalitions = true [
                  set potential-allies interests with [ (policygoal = [policygoal] of myself) and ( values > [ mypref ] of myself - coalition-v-threshold ) and ( values < [ mypref ] of myself + coalition-v-threshold ) ]
                ]
                set policygoal [ policygoal ] of max-one-of members [current-influence]
                set history-influence fput current-influence history-influence
                ;;create-link-with initiator
              ]
            ]
            [ set coalitions-with-resources coalitions-with-resources with [ who != [ who ] of target ] ]
          ]
        ]
        set lobbying false
        set allying false
        set biding-time false
      ]
    ]

    ask coalitions [
      if policygoal = "decrease quota" [ set color blue ]
      if policygoal = "increase quota" [ set color yellow ]
      set current-influence current-influence + (0.5  * count members)
    ]

    ask interests [
      if in-coalition = false and needfunds = false [ set lobbying true ]
    ]
  ]
  [ ask interests [
    ifelse needfunds = true
    [ set lobbying false]
    [ set lobbying true ]
  ]
  ]

  ask coalitions [
    set n-members count members
    set n-poor count members with [ lfunds < lobbying-cost ]
    set num-environment count members with [itype = "environment"]
    set num-industry count members with [itype = "industry"]
    set mean-values mean [values] of members
    set median-values median [values] of members
    set mean-funding mean [lfunds] of members
    set median-funding median [lfunds] of members
    set mean-influence mean [current-influence] of members
    set median-influence median [current-influence] of members
    set %-environment num-environment / ( (count members) / 100 )
    set %-industry 100 - %-environment

  ]

  ifelse any? coalitions [
    set mean-n-members mean [ n-members ] of coalitions
    set n-poor-e sum [ n-poor ] of coalitions with [ policygoal = "decrease quota" ]
    set n-poor-i sum [ n-poor ] of coalitions with [ policygoal = "increase quota" ]
    set n-coalitions-e count coalitions with [ policygoal = "decrease quota" ]
    set n-coalitions-i count coalitions with [ policygoal = "increase quota" ]
    ask coalitions with [ policygoal = "decrease quota" ] [
      set list-e-members fput n-members list-e-members ]
    ask coalitions with [ policygoal = "increase quota" ] [
      set list-i-members fput n-members list-i-members ]
    ;;show list-e-members
    ;;show list-i-members
   ifelse any? coalitions with [ policygoal = "decrease quota" ] [
      set mean-e-members mean list-e-members ]
    [ set mean-e-members 0 ]
   ifelse any? coalitions with [ policygoal = "increase quota" ] [
      set mean-i-members mean list-i-members ]
    [ set mean-i-members 0 ]
  ]
  [ set mean-n-members 0
    set n-coalitions-e 0
    set n-coalitions-i 0
    set n-poor-e 0
    set n-poor-i 0
  ]

end

;;;;;;;;;;;;;;;;;;;;;; Lobbying Procedure ;;;;;;;;;;;;;;;;;;;;;;
to lobby
  let lobbyists turtles with [ (breed = interests or breed = coalitions) and (lobbying = true) ]
  let e-lobbyists lobbyists with [policygoal = "decrease quota"]
  let i-lobbyists lobbyists with [policygoal = "increase quota"]
  set lobby-e-infl mean [current-influence] of e-lobbyists
  set lobby-i-infl mean [current-influence] of i-lobbyists
  set infl-in-coalitions-i (sum [current-influence] of i-lobbyists with [ breed = coalitions ]) / (sum [ current-influence ] of i-lobbyists / 100)
  set infl-in-coalitions-e (sum [current-influence] of e-lobbyists with [ breed = coalitions ]) / (sum [ current-influence ] of e-lobbyists / 100)
  set plot-influence-ind sum [current-influence] of i-lobbyists
  set plot-influence-env sum [current-influence] of e-lobbyists
  set plot-funding-ind sum [lfunds] of i-lobbyists
  set plot-funding-env sum [lfunds] of e-lobbyists
  let lobby-groups interests with [ lobbying = true or in-coalition = true ]
  set lobby-increase lobby-groups with [policygoal = "increase quota"]
  set lobby-decrease lobby-groups with [policygoal = "decrease quota"]
  if lobby-strategy = "lobby friends" [
    while [ any? lobbyists with [ lfunds > lcost ] ] [
      ask lobbyists  [
        ;;print "I am lobbying"
        if lfunds >= lcost  [
          let lobbyist self
          let ltarget min-one-of pmakers [ abs (values - [ values ] of myself) ]
          set lfunds lfunds - lcost
          ask ltarget [
            let value-difference abs (values - [ values ] of myself)
            let vinfl (1 / (1 + value-difference) )
            let linfl 0
            if PM-influence = "High" [
              set linfl [ current-influence ] of myself / (sum [current-influence] of lobbyists )
            ]
            if PM-influence = "Medium" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 2 )
            ]
            if PM-influence = "Low" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 4 )
            ]
            if linfl > 1 [ set linfl 1 ]
            let influence-probability vinfl * linfl
            if influence-probability >= random-float 1
            [ if [policygoal] of lobbyist = "increase quota" [
              set favor favor - 1
            ]
            if [policygoal] of lobbyist = "decrease quota" [
              set favor favor + 1
            ]
            if favor < 0 [ set favor 0 ]
            if favor > 10 [set favor 10 ]
            ]
          ]
        ]
      ]
    ]
  ]

  if lobby-strategy = "lobby foes" [
    while [ any? lobbyists with [ lfunds > lcost ] ] [
      ask lobbyists  [
        ;;print "I am lobbying"
        if lfunds >= lcost  [
          let lobbyist self
          let ltarget min-one-of pmakers [ abs (values - [ values ] of myself) ]
          set lfunds lfunds - lcost
          ask ltarget [
            let value-difference abs (values - [ values ] of myself)
            let vinfl (1 / (1 + value-difference) )
            let linfl 0
            if PM-influence = "High" [
              set linfl [ current-influence ] of myself / (sum [current-influence] of lobbyists )
            ]
            if PM-influence = "Medium" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 2 )
            ]
            if PM-influence = "Low" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 4 )
            ]
            if linfl > 1 [ set linfl 1 ]
            let influence-probability vinfl * linfl
            if influence-probability >= random-float 1
            [ if [policygoal] of lobbyist = "increase quota" [
              set favor favor - 1
            ]
            if [policygoal] of lobbyist = "decrease quota" [
              set favor favor + 1
            ]
            if favor < 0 [ set favor 0 ]
            if favor > 10 [set favor 10 ]
            ]
          ]
        ]
      ]
    ]
  ]

  if lobby-strategy = "lobby undecided" [
    while [ any? lobbyists with [ lfunds > lcost ] ] [
      ask lobbyists  [
        if lfunds >= lcost  [
          let lobbyist self
          let ltarget min-one-of pmakers [ abs (5.5 - favor)  ]
          set lfunds lfunds - lcost
          ask ltarget [
            let value-difference abs (values - [ values ] of myself)
            let vinfl (1 / (1 + value-difference) )
            let linfl 0
            if PM-influence = "High" [
              set linfl [ current-influence ] of myself / (sum [current-influence] of lobbyists )
            ]
            if PM-influence = "Medium" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 2 )
            ]
            if PM-influence = "Low" [
              set linfl [ current-influence ] of myself / ( ( sum [current-influence] of lobbyists ) / 4 )
            ]
            if linfl > 1 [ set linfl 1 ]
            let influence-probability vinfl * linfl
            if influence-probability >= random-float 1
            [ if [policygoal] of lobbyist = "increase quota" [
              set favor favor - 1
              ;;print "persuaded to increase"
            ]
            if [policygoal] of lobbyist = "decrease quota" [
              set favor favor + 1
              ;;print "persuaded to decrease"
            ]
            if favor < 0 [ set favor 0 ]
            if favor > 10 [set favor 10 ]
            ]
          ]
        ]
      ]
    ]
  ]

end

to vote-and-decide
  if voting = "basic" [
    ask pmakers [
      if favor <= 5
      [ set vote-increase vote-increase + 1
        set color yellow
      ]
      if favor >= 6
      [ set vote-decrease vote-decrease + 1
        set color blue
      ]
    ]

    if vote-increase > vote-decrease
    [ set quota quota + quota-change
      ask indicators [
        set shape "arrow"
        set color yellow
        set heading 0
      ]
    ]
    if vote-increase < vote-decrease
    [ ifelse quota >= quota-change
      [ set quota quota - quota-change ]
      [ set quota 0 ]
    ask indicators [
      set shape "arrow"
      set color blue
      set heading 180
    ]
    ]
    if vote-increase = vote-decrease
    [ set quota quota
      ask indicators [
        set shape "x"
        set color white
        set heading 0
      ]
    ]
    if quota > 1000 [ set quota 1000 ]
  ]

  if voting = "deliberation" [
    let increase-voters pmakers with [ favor <= 5 ]
    let decrease-voters pmakers with [ favor >= 6]
    set quota starting-quota + (count increase-voters * 5) - (count decrease-voters * 5)
    if quota > 1000 [ set quota 1000 ]
    if quota < 0 [ set quota 0 ]
  ]

end

to clear-the-board
  ;;clear-links
  ask coalitions [ die ]
  ask interests [
    set lfunds funding
    set availability true
    set coalition-id who
    set needfunds false
    set biding-time false
    set potential-allies nobody
    set in-coalition false
  ]
  ask pmakers [
    set favor values
    set color white
  ]
  set vote-increase 0
  set vote-decrease 0
  set list-e-members []
  set list-i-members []
end

to report-history
file-open "history.csv"
ask coalitions [
    file-print csv:to-row history-influence
  ]
file-close
end

to report-influence
file-open "influence.csv"
  ask interests with [itype = "environment"] [
    file-print csv:to-row (list influence)
  ]
file-close
end
@#$#@#$#@
GRAPHICS-WINDOW
437
10
695
269
-1
-1
7.6
1
10
1
1
1
0
1
1
1
-16
16
-16
16
0
0
1
ticks
30.0

BUTTON
70
10
133
43
NIL
go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
136
10
199
43
go once
go
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

BUTTON
3
10
66
43
NIL
setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

SLIDER
216
221
388
254
fish-population
fish-population
100
10000
5000.0
100
1
NIL
HORIZONTAL

SLIDER
215
258
387
291
reproduction-rate
reproduction-rate
0
2
0.2
0.1
1
NIL
HORIZONTAL

SLIDER
215
295
387
328
carrying-capacity
carrying-capacity
500
10000
10000.0
100
1
NIL
HORIZONTAL

SLIDER
16
478
188
511
starting-quota
starting-quota
0
2000
500.0
100
1
NIL
HORIZONTAL

SLIDER
457
439
630
472
pro-environmental%
pro-environmental%
0
100
0.0
1
1
%
HORIZONTAL

SLIDER
454
286
626
319
issue-salience
issue-salience
0
1
1.0
0.1
1
NIL
HORIZONTAL

SLIDER
457
363
629
396
bias-industry
bias-industry
0
100
0.0
1
1
NIL
HORIZONTAL

SLIDER
457
402
629
435
bias-environment
bias-environment
0
100
0.0
1
1
NIL
HORIZONTAL

SLIDER
216
37
390
70
concern-threshold-industry
concern-threshold-industry
0
1000
480.0
10
1
NIL
HORIZONTAL

SLIDER
216
74
389
107
concern-threshold-environment
concern-threshold-environment
0
10000
4000.0
100
1
NIL
HORIZONTAL

SLIDER
245
505
418
538
mean-influence-industry
mean-influence-industry
0
30
20.0
1
1
NIL
HORIZONTAL

SLIDER
247
582
420
615
mean-funding-industry
mean-funding-industry
0
100
40.0
1
1
NIL
HORIZONTAL

SLIDER
248
618
420
651
mean-funding-environment
mean-funding-environment
0
100
10.0
1
1
NIL
HORIZONTAL

SLIDER
458
477
602
510
lobbying-cost
lobbying-cost
0
100
10.0
1
1
NIL
HORIZONTAL

SLIDER
457
327
629
360
coalition-v-threshold
coalition-v-threshold
0
100
2.0
1
1
NIL
HORIZONTAL

CHOOSER
18
104
169
149
lobby-strategy
lobby-strategy
"lobby friends" "lobby foes" "lobby undecided"
2

SLIDER
15
515
187
548
quota-change
quota-change
0
500
50.0
1
1
NIL
HORIZONTAL

PLOT
981
151
1333
293
fish population & income
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"fish population" 1.0 0 -13345367 true "" "if ticks > 0 [plot fishpop]"
"industry income" 1.0 0 -987046 true "" "if ticks > 0 [plot income]"

PLOT
702
13
1073
147
Voting results
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"Increase Q" 1.0 1 -2674135 true "" "plot vote-increase"
"Decrease Q" 1.0 1 -13345367 true "" "plot vote-decrease"

SWITCH
227
154
376
187
dynamic-salience
dynamic-salience
0
1
-1000

PLOT
980
297
1329
447
Coalitions 
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"industry coalitions" 1.0 0 -5825686 true "" "plot count coalitions with [policygoal = \"increase quota\"]"
"environment coalitions" 1.0 0 -11085214 true "" "plot count coalitions with [policygoal = \"decrease quota\"]"

CHOOSER
21
300
169
345
PM-values
PM-values
"20-60-20" "51-49" "49-51" "40-20-40" "41-20-39" "39-20-41"
0

PLOT
1078
13
1301
147
Quota
NIL
NIL
0.0
10.0
0.0
10.0
true
false
"" ""
PENS
"default" 1.0 0 -16777216 true "" "plot quota"

SLIDER
245
542
418
575
mean-influence-environment
mean-influence-environment
0
30
10.0
1
1
NIL
HORIZONTAL

CHOOSER
255
451
404
496
experiment
experiment
"none" "no IGs" "IGs no coalitions" "IGs & coalitions"
3

CHOOSER
22
349
160
394
voting
voting
"basic" "deliberation" "Sci vs Ind"
0

TEXTBOX
242
197
392
215
Environmental Variables
12
0.0
1

TEXTBOX
63
454
213
472
Quota settings
12
0.0
1

TEXTBOX
240
10
390
28
Interest group settings
12
0.0
1

TEXTBOX
32
280
182
298
Policymaker settings
12
0.0
1

SWITCH
227
119
376
152
single-type-coalitions
single-type-coalitions
0
1
-1000

CHOOSER
18
54
169
99
IG-values
IG-values
"Marginals only" "Centrals only" "Extremes only" "Moderates only" "Normal distribution"
4

CHOOSER
24
397
162
442
PM-influence
PM-influence
"High" "Medium" "Low"
1

PLOT
704
158
970
293
Total influence of lobbyists
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"Industry" 1.0 0 -987046 true "" "plot plot-influence-ind"
"Environment" 1.0 0 -14070903 true "" "plot plot-influence-env"

PLOT
705
296
971
446
Total funding of lobbyists
NIL
NIL
0.0
10.0
0.0
10.0
true
true
"" ""
PENS
"Industry" 1.0 0 -1184463 true "" "plot plot-funding-ind"
"Environment" 1.0 0 -14070903 true "" "plot plot-funding-env"

CHOOSER
16
555
154
600
coalition-formation
coalition-formation
"unlimited" "capped" "probability"
2

SLIDER
459
514
631
547
likelihood-coalition
likelihood-coalition
0
1
0.6
0.1
1
NIL
HORIZONTAL

SLIDER
460
556
632
589
pub-threshold
pub-threshold
1250
5000
5000.0
10
1
NIL
HORIZONTAL

CHOOSER
18
155
156
200
coalition-choice
coalition-choice
"random" "high influence" "high funding"
1

PLOT
705
462
970
596
Influence of lobbyists
NIL
NIL
0.0
10.0
0.0
10.0
true
false
"" ""
PENS
"env lobbyists influence" 1.0 0 -13840069 true "" "plot lobby-e-infl"
"ind lobbyists influence" 1.0 0 -5825686 true "" "plot lobby-i-infl"

CHOOSER
18
208
169
253
coalition-influence
coalition-influence
"sum" "diminishing returns"
0

@#$#@#$#@
## WHAT IS IT?

(a general understanding of what the model is trying to show or explain)

## HOW IT WORKS

(what rules the agents use to create the overall behavior of the model)

## HOW TO USE IT

(how to use the model, including a description of each of the items in the Interface tab)

## THINGS TO NOTICE

(suggested things for the user to notice while running the model)

## THINGS TO TRY

(suggested things for the user to try to do (move sliders, switches, etc.) with the model)

## EXTENDING THE MODEL

(suggested things to add or change in the Code tab to make the model more complicated, detailed, accurate, etc.)

## NETLOGO FEATURES

(interesting or unusual features of NetLogo that the model uses, particularly in the Code tab; or where workarounds were needed for missing features)

## RELATED MODELS

(models in the NetLogo Models Library and elsewhere which are of related interest)

## CREDITS AND REFERENCES

(a reference to the model's URL on the web if it has one, as well as any other necessary credits, citations, and links)
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

boat 3
false
0
Polygon -1 true false 63 162 90 207 223 207 290 162
Rectangle -6459832 true false 150 32 157 162
Polygon -13345367 true false 150 34 131 49 145 47 147 48 149 49
Polygon -7500403 true true 158 37 172 45 188 59 202 79 217 109 220 130 218 147 204 156 158 156 161 142 170 123 170 102 169 88 165 62
Polygon -7500403 true true 149 66 142 78 139 96 141 111 146 139 148 147 110 147 113 131 118 106 126 71

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

factory
false
0
Rectangle -7500403 true true 76 194 285 270
Rectangle -7500403 true true 36 95 59 231
Rectangle -16777216 true false 90 210 270 240
Line -7500403 true 90 195 90 255
Line -7500403 true 120 195 120 255
Line -7500403 true 150 195 150 240
Line -7500403 true 180 195 180 255
Line -7500403 true 210 210 210 240
Line -7500403 true 240 210 240 240
Line -7500403 true 90 225 270 225
Circle -1 true false 37 73 32
Circle -1 true false 55 38 54
Circle -1 true false 96 21 42
Circle -1 true false 105 40 32
Circle -1 true false 129 19 42
Rectangle -7500403 true true 14 228 78 270

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

person business
false
0
Rectangle -1 true false 120 90 180 180
Polygon -13345367 true false 135 90 150 105 135 180 150 195 165 180 150 105 165 90
Polygon -7500403 true true 120 90 105 90 60 195 90 210 116 154 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 183 153 210 210 240 195 195 90 180 90 150 165
Circle -7500403 true true 110 5 80
Rectangle -7500403 true true 127 76 172 91
Line -16777216 false 172 90 161 94
Line -16777216 false 128 90 139 94
Polygon -13345367 true false 195 225 195 300 270 270 270 195
Rectangle -13791810 true false 180 225 195 300
Polygon -14835848 true false 180 226 195 226 270 196 255 196
Polygon -13345367 true false 209 202 209 216 244 202 243 188
Line -16777216 false 180 90 150 165
Line -16777216 false 120 90 150 165

person student
false
0
Polygon -13791810 true false 135 90 150 105 135 165 150 180 165 165 150 105 165 90
Polygon -7500403 true true 195 90 240 195 210 210 165 105
Circle -7500403 true true 110 5 80
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Polygon -1 true false 100 210 130 225 145 165 85 135 63 189
Polygon -13791810 true false 90 210 120 225 135 165 67 130 53 189
Polygon -1 true false 120 224 131 225 124 210
Line -16777216 false 139 168 126 225
Line -16777216 false 140 167 76 136
Polygon -7500403 true true 105 90 60 195 90 210 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

sheep
false
15
Circle -1 true true 203 65 88
Circle -1 true true 70 65 162
Circle -1 true true 150 105 120
Polygon -7500403 true false 218 120 240 165 255 165 278 120
Circle -7500403 true false 214 72 67
Rectangle -1 true true 164 223 179 298
Polygon -1 true true 45 285 30 285 30 240 15 195 45 210
Circle -1 true true 3 83 150
Rectangle -1 true true 65 221 80 296
Polygon -1 true true 195 285 210 285 210 240 240 210 195 210
Polygon -7500403 true false 276 85 285 105 302 99 294 83
Polygon -7500403 true false 219 85 210 105 193 99 201 83

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

wolf
false
0
Polygon -16777216 true false 253 133 245 131 245 133
Polygon -7500403 true true 2 194 13 197 30 191 38 193 38 205 20 226 20 257 27 265 38 266 40 260 31 253 31 230 60 206 68 198 75 209 66 228 65 243 82 261 84 268 100 267 103 261 77 239 79 231 100 207 98 196 119 201 143 202 160 195 166 210 172 213 173 238 167 251 160 248 154 265 169 264 178 247 186 240 198 260 200 271 217 271 219 262 207 258 195 230 192 198 210 184 227 164 242 144 259 145 284 151 277 141 293 140 299 134 297 127 273 119 270 105
Polygon -7500403 true true -1 195 14 180 36 166 40 153 53 140 82 131 134 133 159 126 188 115 227 108 236 102 238 98 268 86 269 92 281 87 269 103 269 113

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.0.4
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
<experiments>
  <experiment name="error_screening2" repetitions="500" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="1"/>
      <value value="10"/>
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="1"/>
      <value value="10"/>
      <value value="60"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="60"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="%central_env">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="8000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="%marginal_industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="%marginal_env">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-set-resourses">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="%central_industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="100"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-set-values">
      <value value="&quot;moderate&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="total" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="1800"/>
      <value value="3200"/>
      <value value="4200"/>
      <value value="4800"/>
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="2000"/>
      <value value="3000"/>
      <value value="4000"/>
      <value value="5000"/>
      <value value="6000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
      <value value="&quot;50-50&quot;"/>
      <value value="&quot;40-20-40&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="CT" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>n-e-members</metric>
    <metric>n-i-members</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
      <value value="500"/>
      <value value="600"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
      <value value="5000"/>
      <value value="6000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="PMVNEW" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>quota</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby foes&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
      <value value="&quot;49-51&quot;"/>
      <value value="&quot;51-49&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="SALNEW" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>quota</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="totals" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="20"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="4800"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="6000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="funtot" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
      <value value="5000"/>
      <value value="6000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="funtotz" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="2000"/>
      <value value="3000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="coalitNEW100" repetitions="1000" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="420"/>
      <value value="480"/>
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="3000"/>
      <value value="4000"/>
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="newfundingNEW" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="10"/>
      <value value="20"/>
      <value value="50"/>
      <value value="100"/>
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="lowcNEW" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="iadvantageNEW" repetitions="150" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>infl-in-coalitions-e</metric>
    <metric>infl-in-coalitions-i</metric>
    <metric>n-poor-e</metric>
    <metric>n-poor-i</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="20"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="concernT" repetitions="150" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="600"/>
      <value value="700"/>
      <value value="800"/>
      <value value="900"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="1000"/>
      <value value="2000"/>
      <value value="3000"/>
      <value value="4000"/>
      <value value="5000"/>
      <value value="6000"/>
      <value value="7000"/>
      <value value="8000"/>
      <value value="9000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="experiment" repetitions="1" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <metric>count turtles</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="RandomForest" repetitions="50" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0"/>
      <value value="0.3"/>
      <value value="0.6"/>
      <value value="0.8"/>
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="RandomForest2" repetitions="100" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <steppedValueSet variable="mean-influence-environment" first="10" step="5" last="40"/>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <steppedValueSet variable="mean-funding-industry" first="10" step="5" last="40"/>
    <steppedValueSet variable="mean-funding-environment" first="10" step="5" last="40"/>
    <steppedValueSet variable="likelihood-coalition" first="0.3" step="0.05" last="0.6"/>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <steppedValueSet variable="mean-influence-industry" first="10" step="5" last="40"/>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="sens-lcoal" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <steppedValueSet variable="likelihood-coalition" first="0.1" step="0.05" last="0.9"/>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="sens-pubt" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="1250"/>
      <value value="2500"/>
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="sens-ncoal" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>list-e-members</metric>
    <metric>list-i-members</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="Koala" repetitions="1000" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <exitCondition>fishpop &lt;= 0</exitCondition>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="Salience" repetitions="1000" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="sens-allies1" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
      <value value="&quot;random&quot;"/>
      <value value="&quot;high funding&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
      <value value="&quot;lobby friends&quot;"/>
      <value value="&quot;lobby foes&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="sens-allies2" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <exitCondition>fishpop &lt;= 0</exitCondition>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
      <value value="&quot;random&quot;"/>
      <value value="&quot;high funding&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
      <value value="&quot;lobby friends&quot;"/>
      <value value="&quot;lobby foes&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="funding1" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="funding2" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <exitCondition>fishpop &lt;= 0</exitCondition>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="influence1" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="influence2" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <exitCondition>fishpop &lt;= 0</exitCondition>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="coalition-infl1" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-influence">
      <value value="&quot;sum&quot;"/>
      <value value="&quot;diminishing returns&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="coalition-infl2" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <exitCondition>fishpop &lt;= 0</exitCondition>
    <metric>fishpop</metric>
    <metric>income</metric>
    <metric>mean-e-members</metric>
    <metric>mean-i-members</metric>
    <metric>n-coalitions-e</metric>
    <metric>n-coalitions-i</metric>
    <metric>plot-influence-ind</metric>
    <metric>plot-influence-env</metric>
    <metric>lobby-e-infl</metric>
    <metric>lobby-i-infl</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-influence">
      <value value="&quot;sum&quot;"/>
      <value value="&quot;diminishing returns&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="ini_fishpop" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
      <value value="&quot;IGs no coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-influence">
      <value value="&quot;sum&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <steppedValueSet variable="fish-population" first="1000" step="1000" last="10000"/>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="ConT" repetitions="200" runMetricsEveryStep="false">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="50"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="1000"/>
      <value value="2000"/>
      <value value="3000"/>
      <value value="4000"/>
      <value value="5000"/>
      <value value="6000"/>
      <value value="7000"/>
      <value value="8000"/>
      <value value="9000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="180"/>
      <value value="320"/>
      <value value="420"/>
      <value value="480"/>
      <value value="500"/>
      <value value="600"/>
      <value value="700"/>
      <value value="800"/>
      <value value="900"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-influence">
      <value value="&quot;sum&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="funding_nove" repetitions="200" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="100"/>
    <metric>fishpop</metric>
    <metric>income</metric>
    <enumeratedValueSet variable="experiment">
      <value value="&quot;IGs &amp; coalitions&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-environment">
      <value value="4000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="concern-threshold-industry">
      <value value="480"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-environment">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-influence-industry">
      <value value="20"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-environment">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="mean-funding-industry">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="likelihood-coalition">
      <value value="0.6"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-formation">
      <value value="&quot;probability&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-choice">
      <value value="&quot;high influence&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="single-type-coalitions">
      <value value="true"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="coalition-v-threshold">
      <value value="2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobbying-cost">
      <value value="10"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="lobby-strategy">
      <value value="&quot;lobby undecided&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-industry">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="bias-environment">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pro-environmental%">
      <value value="0"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-influence">
      <value value="&quot;Medium&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="IG-values">
      <value value="&quot;Normal distribution&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="PM-values">
      <value value="&quot;20-60-20&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="dynamic-salience">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="issue-salience">
      <value value="1"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="pub-threshold">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="voting">
      <value value="&quot;basic&quot;"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="quota-change">
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="starting-quota">
      <value value="500"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="reproduction-rate">
      <value value="0.2"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="fish-population">
      <value value="5000"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="carrying-capacity">
      <value value="10000"/>
    </enumeratedValueSet>
  </experiment>
</experiments>
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
